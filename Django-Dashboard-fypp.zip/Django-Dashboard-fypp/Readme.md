## Admin Dashboard using CanvasJS Python Charts

Run 'py manage.py runserver 8080' to run the sample project
Open http://127.0.0.1:8080/charts/ in browser