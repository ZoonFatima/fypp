from django.urls import path

from .views import home_page, auth
from . import views

urlpatterns = [
    path('', home_page.home_page, name='index'),
    path('login', auth.login, name='login'),
    path('register/', auth.register, name='register'),
    path('patients', home_page.patients, name='patients'),
    path('profile', home_page.profile, name='profile'),
    path('diagnostic-results', home_page.diagnosticResults, name='diagnostic-results'),
    path('recommendations', home_page.recommendations, name='recommendations'),
    path('networking', home_page.networking, name='networking'),
    # Add URLs for the different dashboards
    path('dashboard/bladder-cancer/', views.dashboard_bladder_cancer, name='bladder_cancer'),
    path('dashboard/breast-cancer/', views.dashboard_breast_cancer, name='breast_cancer'),
    path('dashboard/lung-cancer/', views.dashboard_lung_cancer, name='lung_cancer'),
    path('dashboard/skin-cancer/', views.dashboard_skin_cancer, name='skin_cancer'),
]
