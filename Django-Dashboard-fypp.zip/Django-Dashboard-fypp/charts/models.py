# models.py

from django.db import models
# models.py

class DiagnosticResult(models.Model):
    result = models.CharField(max_length=100)  # Diagnostic result (e.g., Positive or Negative)
    description = models.TextField()           # Description of the diagnostic result
    status = models.CharField(max_length=100)   # Status of the diagnostic result (e.g., Cancer Detected or No Cancer Detected)


class Patient(models.Model):
    name = models.CharField(max_length=100)
    gender = models.CharField(max_length=10, choices=[("Male", "Male"), ("Female", "Female")])
    smoker = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No"), ("Unknown", "Unknown")])
    family_history = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No")])
    hematuria = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No")])
    dysuria = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No"), ("Unknown", "Unknown")])
    tumor_grade = models.CharField(max_length=10, choices=[("LG", "LG"), ("HG", "HG"), ("Unknown", "Unknown")])
    tnm_stage = models.CharField(max_length=10, choices=[("pT1", "pT1"), ("pT2", "pT2"), ("pT3", "pT3"), ("pTa", "pTa")])
    primary_tumor = models.CharField(max_length=100)
    mri_number = models.CharField(max_length=50)
   
class Profile(models.Model):
    name = models.CharField(max_length=100)
    designation = models.CharField(max_length=100)
    about = models.TextField()
    specialties = models.TextField()
    department = models.CharField(max_length=100)
    professional_experience = models.TextField()

class Recommendation(models.Model):
    smoker = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No"), ("Unknown", "Unknown")])
    family_history = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No")])
    hematuria = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No")])
    dysuria = models.CharField(max_length=10, choices=[("Yes", "Yes"), ("No", "No"), ("Unknown", "Unknown")])
    gender = models.CharField(max_length=10, choices=[("Male", "Male"), ("Female", "Female")])
    primary_recurrence = models.CharField(max_length=100)
    tumour_grade = models.CharField(max_length=10, choices=[("LG", "LG"), ("HG", "HG"), ("Unknown", "Unknown")])
    tnm_stage = models.CharField(max_length=10, choices=[("pT1", "pT1"), ("pT2", "pT2"), ("pT3", "pT3"), ("pTa", "pTa")])
    site_of_tcc = models.CharField(max_length=100)
     # Recommendation result field
    recommended_method = models.CharField(max_length=100)  # Adjust the max_length as 

# Other models can be added here as needed

# Other models can be added here as needed
