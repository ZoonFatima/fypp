from django.shortcuts import render

def home_page(request):
    return render(request, 'pages/index.html')

def patients(request):
    return render(request, 'pages/patients.html')

def profile(request):
    return render(request, 'pages/profile.html')

def diagnosticResults(request):
    return render(request, 'pages/diagnostic-results.html')

def recommendations(request):
    return render(request, 'pages/recommendations.html')

def networking(request):
    return render(request, 'pages/networking.html')