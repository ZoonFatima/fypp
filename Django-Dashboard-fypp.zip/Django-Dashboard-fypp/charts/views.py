from django.shortcuts import render

def index(request):
    area_data = [
        { "label": "Jan", "y": 10000 },
        { "label": "Feb", "y": 30162 },
        { "label": "Mar", "y": 26263 },
        { "label": "Apr", "y": 18394 },
        { "label": "May", "y": 18287 },
        { "label": "Jun", "y": 28682 },
        { "label": "Jul", "y": 31274 },
        { "label": "Aug", "y": 33259 },
        { "label": "Sep", "y": 25849 },
        { "label": "Oct", "y": 24159 },
        { "label": "Nov", "y": 32651 },
        { "label": "Dec", "y": 31984 }
    ]
    column_data = [
        { "label": "January", "y": 42150 },
        { "label": "February", "y": 53120 },
        { "label": "March", "y": 62510 },
        { "label": "April", "y": 78410 },
        { "label": "May", "y": 98210 },
        { "label": "June", "y": 149840 }
    ]
    pie_data = [
        { "y": 12.21, "name": "2", "color": "#007bff" },
        { "y": 15.58, "name": "3", "color": "#dc3545" },
        { "y": 8.32, "name": "1", "color": "#28a745" }
    ]
    return render(request, 'index.html', { "area_data": area_data, "column_data": column_data, "pie_data": pie_data })

def dashboard_bladder_cancer(request):
    area_data = [
        { "label": "Jan", "y": 5000 },
        { "label": "Feb", "y": 15081 },
        { "label": "Mar", "y": 13131 },
        { "label": "Apr", "y": 9197 },
        { "label": "May", "y": 9143 },
        { "label": "Jun", "y": 14341 },
        { "label": "Jul", "y": 15637 },
        { "label": "Aug", "y": 16630 },
        { "label": "Sep", "y": 12924 },
        { "label": "Oct", "y": 12079 },
        { "label": "Nov", "y": 16325 },
        { "label": "Dec", "y": 15992 }
    ]
    column_data = [
        { "label": "January", "y": 21075 },
        { "label": "February", "y": 26560 },
        { "label": "March", "y": 31255 },
        { "label": "April", "y": 39205 },
        { "label": "May", "y": 49105 },
        { "label": "June", "y": 74920 }
    ]
    pie_data = [
        { "y": 6.1, "name": "A", "color": "#007bff" },
        { "y": 7.79, "name": "B", "color": "#dc3545" },
        { "y": 4.16, "name": "C", "color": "#28a745" }
    ]
    return render(request, 'dashboard.html', { "dashboard_type": "Bladder Cancer", "area_data": area_data, "column_data": column_data, "pie_data": pie_data })

def dashboard_lung_cancer(request):
    area_data = [
        { "label": "Jan", "y": 12000 },
        { "label": "Feb", "y": 36194 },
        { "label": "Mar", "y": 31515 },
        { "label": "Apr", "y": 22073 },
        { "label": "May", "y": 21944 },
        { "label": "Jun", "y": 34375 },
        { "label": "Jul", "y": 37452 },
        { "label": "Aug", "y": 39870 },
        { "label": "Sep", "y": 31019 },
        { "label": "Oct", "y": 29002 },
        { "label": "Nov", "y": 39181 },
        { "label": "Dec", "y": 38380 }
    ]
    column_data = [
        { "label": "January", "y": 50580 },
        { "label": "February", "y": 63744 },
        { "label": "March", "y": 75012 },
        { "label": "April", "y": 94092 },
        { "label": "May", "y": 117852 },
        { "label": "June", "y": 179808 }
    ]
    pie_data = [
        { "y": 6.1, "name": "A", "color": "#007bff" },
        { "y": 7.79, "name": "B", "color": "#dc3545" },
        { "y": 4.16, "name": "C", "color": "#28a745" }
    ]
    return render(request, 'dashboard.html', { "dashboard_type": "Lung Cancer", "area_data": area_data, "column_data": column_data, "pie_data": pie_data })

def dashboard_skin_cancer(request):
    area_data = [
        { "label": "Jan", "y": 12000 },
        { "label": "Feb", "y": 36194 },
        { "label": "Mar", "y": 31515 },
        { "label": "Apr", "y": 22073 },
        { "label": "May", "y": 21944 },
        { "label": "Jun", "y": 34375 },
        { "label": "Jul", "y": 37452 },
        { "label": "Aug", "y": 39870 },
        { "label": "Sep", "y": 31019 },
        { "label": "Oct", "y": 29002 },
        { "label": "Nov", "y": 39181 },
        { "label": "Dec", "y": 38380 }
    ]
    column_data = [
        { "label": "January", "y": 50580 },
        { "label": "February", "y": 63744 },
        { "label": "March", "y": 75012 },
        { "label": "April", "y": 94092 },
        { "label": "May", "y": 117852 },
        { "label": "June", "y": 179808 }
    ]
    pie_data = [
        { "y": 6.1, "name": "A", "color": "#007bff" },
        { "y": 7.79, "name": "B", "color": "#dc3545" },
        { "y": 4.16, "name": "C", "color": "#28a745" }
    ]
    return render(request, 'dashboard.html', { "dashboard_type": "Skin Cancer", "area_data": area_data, "column_data": column_data, "pie_data": pie_data })
