// All javascript code in this project for now is just for demo DON'T RELY ON IT

const random = (max = 100) => {
  return Math.round(Math.random() * max) + 20
}

const randomData = () => {
  return [
    random(),
    random(),
    random(),
    random(),
    random(),
    random(),
    random(),
    random(),
    random(),
    random(),
    random(),
    random(),
  ]
}

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

const cssColors = (color) => {
  return getComputedStyle(document.documentElement).getPropertyValue(color)
}

const getColor = () => {
  return window.localStorage.getItem('color') ?? 'cyan'
}

const colors = {
  primary: cssColors(`--color-${getColor()}`),
  primaryLight: cssColors(`--color-${getColor()}-light`),
  primaryLighter: cssColors(`--color-${getColor()}-lighter`),
  primaryDark: cssColors(`--color-${getColor()}-dark`),
  primaryDarker: cssColors(`--color-${getColor()}-darker`),
}

const barChart = new Chart(document.getElementById('barChart'), {
  type: 'bar',
  data: {
    labels: ['Bladder','Adenocarcinoma','Amyloidosis','Stone','Infections','Kidney Cysts/Bladder Cyst','Mets','Ureteric Stone','Pelvicalayceal System','Cystitis','IMFT','Renal Pelvis','Paraganglioma','Other (unique words)'],
    datasets: [
      {
        data: [28.59,8.71,19.63,4.40,3.39,3.21,2.37,2.29,1.86,1.78,1.70,1.52,1.01,19.45],
        backgroundColor: colors.primary,
        hoverBackgroundColor: colors.primaryDark,
      },
    ],
  },
  options: {
    cornerRadius: 2,
    maintainAspectRatio: false,
    legend: {
      display: false,
    },
  },
})

const ageChart = new Chart(document.getElementById('ageChart'), {
  type: 'pie',
  data: {
    labels: ['Male', 'Female'],
    datasets: [
      {
        data: [77.31, 22.68],
        backgroundColor: [colors.primary, colors.primaryLighter],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})

const smokerChart = new Chart(document.getElementById('smokerChart'), {
  type: 'pie',
  data: {
    labels: ['Smoker', 'Non-Smoker', 'Unknown'],
    datasets: [
      {
        data: [7.02, 26.96, 66.02],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})

const familyHistory = new Chart(document.getElementById('familyHistory'), {
  type: 'pie',
  data: {
    labels: ['Yes', 'No'],
    datasets: [
      {
        data: [27.11, 72.89],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})
const hematuria = new Chart(document.getElementById('hematuria'), {
  type: 'doughnut',
  data: {
    labels: ['Yes', 'No'],
    datasets: [
      {
        data: [75.70, 24.30],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})

const Dysuria = new Chart(document.getElementById('Dysuria'), {
  type: 'pie',
  data: {
    labels: ['Yes', 'No', 'Unknown'],
    datasets: [
      {
        data: [9.48, 39.75, 50.77],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})

const Cytoscopy = new Chart(document.getElementById('Cytoscopy'), {
  type: 'doughnut',
  data: {
    labels: ['Yes', 'No'],
    datasets: [
      {
        data: [57.74, 42.26],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})


const UrineCytology = new Chart(document.getElementById('UrineCytology'), {
  type: 'doughnut',
  data: {
    labels: ['Yes', 'No'],
    datasets: [
      {
        data: [6.18, 93.82],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})

const TumorGrade = new Chart(document.getElementById('TumorGrade'), {
  type: 'pie',
  data: {
    labels: ['High Grade', 'Low Grade', 'Unknown'],
    datasets: [
      {
        data: [43.95, 8.29, 47.76],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})

const TNMStage = new Chart(document.getElementById('TNMStage'), {
  type: 'bar',
  data: {
    labels: ['pT1','pTa','pT2', 'Nil'],
    datasets: [
      {
        data: [4.50,2.04,1.34, 92.12],
        backgroundColor: colors.primary,
        hoverBackgroundColor: colors.primaryDark,
      },
    ],
  },
  options: {
    cornerRadius: 2,
    maintainAspectRatio: false,
    legend: {
      display: false,
    },
  },
})


// const activeUsersChart = new Chart(document.getElementById('activeUsersChart'), {
//   type: 'bar',
//   data: {
//     labels: [...randomData(), ...randomData()],
//     datasets: [
//       {
//         data: [...randomData(), ...randomData()],
//         backgroundColor: colors.primary,
//         borderWidth: 0,
//         categoryPercentage: 1,
//       },
//     ],
//   },
//   options: {
//     scales: {
//       yAxes: [
//         {
//           display: false,
//           gridLines: false,
//         },
//       ],
//       xAxes: [
//         {
//           display: false,
//           gridLines: false,
//         },
//       ],
//       ticks: {
//         padding: 10,
//       },
//     },
//     cornerRadius: 2,
//     maintainAspectRatio: false,
//     legend: {
//       display: false,
//     },
//     tooltips: {
//       prefix: 'Users',
//       bodySpacing: 4,
//       footerSpacing: 4,
//       hasIndicator: true,
//       mode: 'index',
//       intersect: true,
//     },
//     hover: {
//       mode: 'nearest',
//       intersect: true,
//     },
//   },
// })

const lineChart = new Chart(document.getElementById('lineChart'), {
  type: 'line',
  data: {
    labels: months,
    datasets: [
      {
        label: 'GenX',
        data: randomData(),
        fill: false,
        borderColor: 'red',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 0,
      },
      {
        label: 'Urine Cytoscopy',
        data: randomData(),
        fill: false,
        borderColor: 'green',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 0,
      },
      {
        label: 'Urine  Cytology',
        data: randomData(),
        fill: false,
        borderColor: colors.primary,
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 0,
      },
    ],
  },
  options: {
    responsive: true,
    scales: {
      yAxes: [
        {
          gridLines: false,
          ticks: {
            beginAtZero: false,
            stepSize: 50,
            fontSize: 12,
            fontColor: '#97a4af',
            fontFamily: 'Open Sans, sans-serif',
            padding: 20,
          },
        },
      ],
      xAxes: [
        {
          gridLines: false,
        },
      ],
    },
    maintainAspectRatio: false,
    legend: {
      display: true,
    },
    tooltips: {
      hasIndicator: true,
      intersect: false,
    },
  },
})

const PRM = new Chart(document.getElementById('PRM'), {
  type: 'doughnut',
  data: {
    labels: ['Recurrence' ,'Unknown' ,'Mets' ,'Others'],
    datasets: [
      {
        data: [32.44,18.03,14.68,1.57],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})

const Expert = new Chart(document.getElementById('Expert'), {
  type: 'doughnut',
  data: {
    labels: ['Positive', 'Negative'],
    datasets: [
      {
        data: [28.99, 71.01],
        backgroundColor: [colors.primary, colors.primaryLighter, colors.primaryLight],
        hoverBackgroundColor: colors.primaryDark,
        borderWidth: 0,
        weight: 0.5,
      },
    ],
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: 'bottom',
    },

    title: {
      display: false,
    },
    animation: {
      animateScale: true,
      animateRotate: true,
    },
  },
})


let randomUserCount = 0

const usersCount = document.getElementById('usersCount')

const fakeUsersCount = () => {
  randomUserCount = random()
  activeUsersChart.data.datasets[0].data.push(randomUserCount)
  activeUsersChart.data.datasets[0].data.splice(0, 1)
  activeUsersChart.update()
  usersCount.innerText = randomUserCount
}

setInterval(() => {
  fakeUsersCount()
}, 1000)
